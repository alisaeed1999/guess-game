package sample;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Main extends Application {

    public static int num;
    int lives = 6;

    public static void main(String[] args) {
        num = ((int)(Math.random()*100)+1);
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        // create Text field using class TextField to get input from user
        TextField UserGuess = new TextField();

        // create Labels using class Label to print my messages and result of my guessing
        Label label_welcome = new Label("Guess the Secret Number");
        label_welcome.setFont(new Font("Time new Roman", 16)); // set the font type and size
        Label label_rules = new Label("I'm thinking of a Number between 1 and 100");
        Label label_ask = new Label("Your Guess?");
        Label live = new Label("your lives is "+ lives+" lives");
        live.setFont(new Font( "Time new Roman" , 12)); // set the font type and size

        Button button_submit = new Button("submit");
        button_submit.setDefaultButton(true);
        Button button_Giveup = new Button("Give Up");
        button_Giveup.setCancelButton(true);

        button_Giveup.setOnAction(event -> {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Give Up");
            alert.setHeaderText("the right number is "+num+" good luck next time");
            alert.setContentText(null);
            alert.showAndWait();

            lives = 6;
            live.setText("your lives is "+ lives+" lives");

            num = ((int)(Math.random()*100)+1);
        });

        button_submit.setOnAction(event -> {

            int guess;

            Alert alert;
            try {
                guess = Integer.parseUnsignedInt(UserGuess.getText());
            }catch (NumberFormatException ex) {
                guess = -1 ;
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("ERROR");
                alert.setHeaderText("Invalid vlaue");
                alert.setContentText("enter a positive number between 1 and 100");
                alert.showAndWait();
            }
            if(guess != -1) {
                if (guess > num) {
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Wrong Value");
                    alert.setHeaderText("Guess lower Number");
                } else if (guess < num) {
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Wrong Value");
                    alert.setHeaderText("Guess higher Number");
                } else {
                    alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("correct Value");
                    alert.setHeaderText("Good Job");

                    num = ((int) (Math.random() * 100) + 1);
                    lives = 7;
                }

                if (lives < 5) {
                    if (num % 2 == 0) {
                        alert.setContentText("Hint : the right number is an even");
                    } else {
                        alert.setContentText("Hint : the right number is an odd");
                    }
                }
                alert.showAndWait();
            }
            UserGuess.setText("");
                if (lives == 0)
                {
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Game Over");
                    alert.setHeaderText("Game Over !! Good Luck Next Time");
                    alert.setContentText("The Right Number Is "+num);
                    alert.showAndWait();
                    lives = 6;
                    num = ((int)(Math.random()*100)+1);
                }else {
                    lives --;
                }
                live.setText("your lives is "+ lives+" lives");
        });
        // create my  panes  to add my controllers on it
        HBox Guess = new HBox(live);
        Guess.setAlignment(Pos.CENTER);
        HBox userNumber = new HBox(label_ask,UserGuess);
        userNumber.setAlignment(Pos.CENTER);
        userNumber.setSpacing(15);
        HBox buttons = new HBox(button_submit,button_Giveup);
        buttons.setAlignment(Pos.CENTER);
        buttons.setSpacing(50);
        HBox welcome = new HBox(label_welcome);
        welcome.setAlignment(Pos.CENTER);
        HBox rules = new HBox(label_rules);
        rules.setAlignment(Pos.CENTER);

        VBox Game = new VBox(welcome,userNumber,buttons,Guess,rules);
        Game.setSpacing(10);
        Game.setAlignment(Pos.CENTER);
        Game.setPadding(new Insets(10,10,10,10));


        Scene GuessGame = new Scene(Game, 300, 160);

        primaryStage.setTitle("Guess Game");
        primaryStage.setScene(GuessGame);
        primaryStage.show();

    }


}
